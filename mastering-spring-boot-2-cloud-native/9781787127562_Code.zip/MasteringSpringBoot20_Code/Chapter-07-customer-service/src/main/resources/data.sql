INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1000, 'Dinesh Rajput', '94312XX223', 'dineshxxx@mail.com', 'Noida');
INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1001, 'Arnav Rajput', '54312XX223', 'arnavxxx@mail.com', 'Noida');
INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1002, 'Anamika Rajput', '54312XX223', 'anamikaxxx@mail.com', 'Noida');
INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1003, 'Adesh Rajput', '74312XX223', 'adeshxxx@mail.com', 'Delhi');
INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1004, 'Vinesh Rajput', '44312XX223', 'vineshxxx@mail.com', 'Mumbai');
INSERT INTO CUSTOMER (customerId, customerName, mobile, email, city) values (1005, 'Pradeep Rajput', '84312XX223', 'pradeepxxx@mail.com', 'Gurugram');
