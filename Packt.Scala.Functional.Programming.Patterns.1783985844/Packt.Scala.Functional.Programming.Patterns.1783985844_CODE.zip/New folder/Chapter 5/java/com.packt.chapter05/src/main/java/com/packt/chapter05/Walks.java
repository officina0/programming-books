package com.packt.chapter05;

public interface Walks extends NameIt {
	public void walk();
}

