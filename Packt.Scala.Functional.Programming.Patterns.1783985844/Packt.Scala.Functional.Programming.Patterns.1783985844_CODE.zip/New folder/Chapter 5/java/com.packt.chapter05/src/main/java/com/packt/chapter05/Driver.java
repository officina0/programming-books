package com.packt.chapter05;

public class Driver {
	public static void main(String[] args) {
		 Horse horse = new Horse();
		 Donkey donkey = new Donkey();	
		 donkey.walk();
		 donkey.moveGoods();
		 horse.walk();
	}
}

