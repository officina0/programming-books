package com.packt.chapter05;

public interface GoodsMover extends NameIt {
	void moveGoods();
}
