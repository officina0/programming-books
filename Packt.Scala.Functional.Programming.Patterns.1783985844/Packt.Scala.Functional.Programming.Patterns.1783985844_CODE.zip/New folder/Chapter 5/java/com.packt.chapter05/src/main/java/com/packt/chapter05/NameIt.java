package com.packt.chapter05;

public interface NameIt {
	public String name();
}

