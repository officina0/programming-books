package com.packt.chapter05;

public interface Doctor {
	void innoculate(Animal animal);
}
