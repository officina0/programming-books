package chap04;

public interface Image {
	public void load();
	public void renderImage();
}
