package chapter1;

public interface Predicate {

	boolean apply(int nextElem, int currElem);

}