The following two commands should get it running for you.
	javac Driver.java
	java Driver

   
