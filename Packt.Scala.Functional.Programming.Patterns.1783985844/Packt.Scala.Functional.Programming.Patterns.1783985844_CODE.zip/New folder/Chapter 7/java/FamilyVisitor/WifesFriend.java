
public class WifesFriend extends Friend {

	public WifesFriend(String name) {
		super(name);
	}

	@Override
	public void greetedBy(Husband husband) {

	}

	@Override
	public void greetedBy(Wife wife) {

	}

}
