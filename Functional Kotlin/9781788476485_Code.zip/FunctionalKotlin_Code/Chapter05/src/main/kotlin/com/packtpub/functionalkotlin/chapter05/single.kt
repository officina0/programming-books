package com.packtpub.functionalkotlin.chapter05


/*
fun sum(a:Int, b:Int): Int {
	return a + b
}*/

//fun sum(a:Int, b:Int): Int = a + b
fun sum(a:Int, b:Int) = a + b