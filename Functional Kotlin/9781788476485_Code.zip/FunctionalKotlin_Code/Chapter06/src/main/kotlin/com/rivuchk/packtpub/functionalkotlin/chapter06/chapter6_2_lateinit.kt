package com.rivuchk.packtpub.functionalkotlin.chapter06


lateinit var notNullStr1:String
lateinit var notInit1:String

fun main(args: Array<String>) {
    notNullStr1 = "Initial value"
    println(notNullStr1)
    println(notInit1)
}