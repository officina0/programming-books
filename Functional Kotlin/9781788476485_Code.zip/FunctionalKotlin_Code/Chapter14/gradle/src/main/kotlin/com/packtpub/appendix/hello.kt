package com.packtpub.appendix

fun main(args: Array<String>) {
	println("Hello, World!")
}