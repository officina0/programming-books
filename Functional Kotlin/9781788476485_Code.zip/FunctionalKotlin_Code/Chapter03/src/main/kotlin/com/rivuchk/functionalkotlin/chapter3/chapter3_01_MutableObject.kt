package com.rivuchk.functionalkotlin.chapter3

class MutableObject {
    var mutableProperty:Int = 1
}

fun main(args: Array<String>) {
    val mutableObj = MutableObject()

    
}