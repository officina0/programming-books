package com.rivuchk.functionalkotlin.chapter3

fun main(args: Array<String>) {
    var x:String = "abc"
    var y = x.capitalize()
    println("x = $x, y = $y")
}