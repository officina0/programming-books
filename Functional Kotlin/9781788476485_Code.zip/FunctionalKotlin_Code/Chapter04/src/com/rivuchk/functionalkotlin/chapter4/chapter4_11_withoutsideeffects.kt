package com.rivuchk.functionalkotlin.chapter4

fun addNumbers(a:Int = 0,b:Int = 0):Int {
    return a+b
}

fun main(args: Array<String>) {
    println()
}