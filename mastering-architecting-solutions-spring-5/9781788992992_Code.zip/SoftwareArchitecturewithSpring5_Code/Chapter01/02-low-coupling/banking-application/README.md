# Low coupling

This project example consist of some classes that were refactored from the highly couple example project.
A couple of classes has been created containing unit tests for the implemented code:

- BankStatementServiceTest
- CustomerServiceTest