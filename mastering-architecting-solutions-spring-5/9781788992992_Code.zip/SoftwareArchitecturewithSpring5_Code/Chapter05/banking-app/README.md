# Spring MVC

Run the app using the main `class BankingAppApplication`

The application will be available in the URL `https://localhost:8443/`

You can play with the app using the following credentials:

username: rene
password: rene


username: matt
password: matt

