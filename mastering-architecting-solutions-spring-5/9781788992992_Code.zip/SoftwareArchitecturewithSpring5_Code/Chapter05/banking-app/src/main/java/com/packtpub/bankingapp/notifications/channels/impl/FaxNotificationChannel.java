package com.packtpub.bankingapp.notifications.channels.impl;

import com.packtpub.bankingapp.notifications.channels.NotificationChannel;
import org.springframework.stereotype.Component;


@Component
public class FaxNotificationChannel implements NotificationChannel {

}
