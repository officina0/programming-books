package com.packtpub.bankingapp.notifications.domain;

public enum NotificationType {

    EMAIL, FAX
}
