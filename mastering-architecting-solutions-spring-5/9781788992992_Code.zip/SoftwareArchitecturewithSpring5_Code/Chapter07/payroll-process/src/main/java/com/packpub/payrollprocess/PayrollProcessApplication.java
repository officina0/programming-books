package com.packpub.payrollprocess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayrollProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayrollProcessApplication.class, args);
	}
}
