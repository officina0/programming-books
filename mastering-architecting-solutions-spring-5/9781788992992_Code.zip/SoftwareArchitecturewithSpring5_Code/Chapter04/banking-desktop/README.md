# JavaFX client

This is a JavaFX project that is used to show a desktop can work as a client of a REST API.

Run the application using the BankingClientApplication and use the credentials

```
username: rene
password: rene
``` 