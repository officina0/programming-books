package com.packtpub.bankingclient.ui;

public class NavigableController {

    protected LayoutPane layout;

    public void setLayout(LayoutPane layout) {
        this.layout = layout;
    }
}
