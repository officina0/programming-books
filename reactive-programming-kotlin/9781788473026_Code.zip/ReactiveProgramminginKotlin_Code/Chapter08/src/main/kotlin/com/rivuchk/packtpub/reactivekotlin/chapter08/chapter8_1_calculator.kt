package com.rivuchk.packtpub.reactivekotlin.chapter8

fun add(a:Int, b:Int):Int = a+b
fun substract(a:Int, b:Int):Int = a-b
fun mult(a:Int, b:Int):Int = a*b
fun divide(a:Int, b:Int):Int = a/b
