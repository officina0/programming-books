package com.rivuchk.reactivekotlin.springdi.employee_task

interface Task {
    fun execute()
}