package com.rivuchk.reactivekotlin.springdi.employee_task

class RandomTask : Task {
    override fun execute() {
        println("Executing Random Task")
    }
}