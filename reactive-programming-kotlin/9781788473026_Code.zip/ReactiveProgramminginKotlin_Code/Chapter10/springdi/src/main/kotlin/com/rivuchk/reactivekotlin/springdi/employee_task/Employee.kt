package com.rivuchk.reactivekotlin.springdi.employee_task

interface Employee {
    fun executeTask()
}