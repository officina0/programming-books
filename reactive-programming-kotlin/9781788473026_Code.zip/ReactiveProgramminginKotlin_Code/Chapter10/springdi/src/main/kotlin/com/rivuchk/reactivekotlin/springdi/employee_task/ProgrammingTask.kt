package com.rivuchk.reactivekotlin.springdi.employee_task

class ProgrammingTask: Task {
    override fun execute() {
        println("Writing Programms")
    }

}