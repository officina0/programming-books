package quickstartguide.kotlin.chapter5.sets

val superHeros = setOf("Batman", "Superman")
val superHeros2 = hashSetOf("Thor", "Spider-Man")
val superHeros3 = linkedSetOf("Iron-Man", "Wolverine")
val sortedNums = sortedSetOf(3,10,12,4,9)
val empty = emptySet<String>()

val mutableSet = mutableSetOf("Hulk", "DareDevil")