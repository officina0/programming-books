private fun sayMyName(name: String) {
    println(name)
}

fun accessPrivateFunction() {
    sayMyName("John")
}