val str = "Kotlin"

fun typeSafety() {
    var str = "Kotlin"
    str = 1 // compiler error
}
