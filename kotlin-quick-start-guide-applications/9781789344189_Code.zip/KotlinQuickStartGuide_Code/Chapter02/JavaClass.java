public class JavaClass {
    public void foo() {
        FileDeclarationKt.fileLevelFunction();
    }
}