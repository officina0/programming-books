package quickstartguide.kotlin.chapter2

import java.lang.Math.PI

fun circumference(radius: Double): Double  {
    return 2 * PI * radius
}