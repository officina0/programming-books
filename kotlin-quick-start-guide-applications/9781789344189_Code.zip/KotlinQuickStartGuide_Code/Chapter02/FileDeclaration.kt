fun fileLevelFunction() {
    println("I'm declared without a class")
}