import quickstartguide.kotlin.chapter2.circumference

val circ = circumference(10.0)


