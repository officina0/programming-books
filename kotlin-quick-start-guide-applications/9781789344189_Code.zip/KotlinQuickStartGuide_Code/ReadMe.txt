Since Kotlin compiles to Java bytecode and uses Java's types and build tools (Maven and Gradle), readers with a Java background will probably find Kotlin a bit easier than those without. 
But a Java background is not a requirement, as this book is intended for readers who are completely new to Kotlin/Java and the JVM ecosystem. 

This book doesn't teach programming, so readers that have knowledge of any modern general-purpose programming language will find content in this book more understandable than those who don't.