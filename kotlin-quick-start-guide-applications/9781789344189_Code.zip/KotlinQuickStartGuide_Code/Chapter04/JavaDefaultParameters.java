package quickstart.kotlin.chapter4;

public class JavaDefaultParameters {

    public void s() {
        "".indexOf()
    }
}
