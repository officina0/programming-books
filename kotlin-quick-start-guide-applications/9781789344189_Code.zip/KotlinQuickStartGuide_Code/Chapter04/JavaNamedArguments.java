package quickstart.kotlin.chapter4;

public class JavaNamedArguments {
    public void replaceInString() {
        String str = "foo";
        boolean match = str.regionMatches(true, 0, "foo", 0, 3);
    }

    public void foo(int a, int b) {

    }
}
