package quickstart.kotlin.chapter4

fun closure() {
    var a = 0
    val closure = {
        a++
    }
}