package quickstart.kotlin.chapter4;

public class JavaVarargs {

    public int sumNumbers(int... nums) {

    }
}
