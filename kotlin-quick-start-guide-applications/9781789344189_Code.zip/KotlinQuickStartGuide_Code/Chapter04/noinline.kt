package quickstart.kotlin.chapter4

inline fun noInlineExample(first: () -> String, noinline second: () -> String) {

}