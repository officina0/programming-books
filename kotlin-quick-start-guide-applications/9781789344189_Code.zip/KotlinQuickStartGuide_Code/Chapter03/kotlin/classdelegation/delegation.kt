package quickstartguide.kotlin.chapter3.kotlin.classdelegation

