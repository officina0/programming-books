package quickstartguide.kotlin.chapter3.kotlin.constructors

val user = User("John", "Doe", 1990)