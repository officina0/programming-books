package com.packt.kotlinquickstart.dictionary.data

data class DictionaryEntry(val term: String, val explanation: String)