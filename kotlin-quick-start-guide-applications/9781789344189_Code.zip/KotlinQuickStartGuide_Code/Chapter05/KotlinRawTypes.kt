package quickstart.kotlin.chapter6

class NoRawTypes {
    //compiler error
    private lateinit var comparable: Comparable
}