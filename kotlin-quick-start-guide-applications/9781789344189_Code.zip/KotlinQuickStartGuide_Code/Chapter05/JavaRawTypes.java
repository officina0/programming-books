package quickstart.kotlin.chapter6;

public class JavaRawTypes {
    private Comparable comparable;
}
